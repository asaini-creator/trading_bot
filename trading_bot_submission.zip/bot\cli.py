"""
cli.py
CLI entry point for the trading bot.
"""

import argparse
import os
import sys

from .logging_config import setup_logger
from .client import BinanceFuturesTestnetClient, BinanceClientError
from .orders import execute_order


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Simplified trading bot for Binance Futures Testnet (USDT-M).",
    )
    parser.add_argument("--symbol", required=True, help="Trading pair symbol, e.g. BTCUSDT")
    parser.add_argument("--side", required=True, choices=["BUY", "SELL", "buy", "sell"], help="Order side")
    parser.add_argument("--type", required=True, dest="order_type",
                         choices=["MARKET", "LIMIT", "market", "limit"], help="Order type")
    parser.add_argument("--quantity", required=True, help="Order quantity")
    parser.add_argument("--price", required=False, default=None, help="Price (required for LIMIT orders)")
    return parser


def main():
    logger = setup_logger()
    parser = build_parser()
    args = parser.parse_args()

    api_key = os.environ.get("BINANCE_API_KEY")
    api_secret = os.environ.get("BINANCE_API_SECRET")

    if not api_key or not api_secret:
        logger.error("Missing API credentials in environment variables.")
        print("[FAILED] Please set BINANCE_API_KEY and BINANCE_API_SECRET environment variables.")
        sys.exit(1)

    try:
        client = BinanceFuturesTestnetClient(api_key, api_secret)
    except BinanceClientError as exc:
        logger.error("Client initialization failed: %s", exc)
        print(f"[FAILED] Could not connect to Binance Futures Testnet: {exc}")
        sys.exit(1)

    success = execute_order(
        client=client,
        symbol=args.symbol,
        side=args.side,
        order_type=args.order_type,
        quantity=args.quantity,
        price=args.price,
    )

    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()