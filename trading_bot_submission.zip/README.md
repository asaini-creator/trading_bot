# Trading Bot – Binance Futures Testnet (USDT-M)

A simplified Python CLI trading bot that places MARKET and LIMIT orders
(BUY/SELL) on the Binance USDT-M Futures Testnet, with input validation,
structured logging, and clean error handling.

## Setup Steps

1. Register at https://testnet.binancefuture.com and generate API credentials.
2. Install Python 3.9+.
3. Create and activate a virtual environment: