"""
client.py
Binance Futures Testnet (USDT-M) client wrapper.
This module is the ONLY place that talks to the Binance API.
"""

import logging
from binance.client import Client
from binance.exceptions import BinanceAPIException, BinanceOrderException, BinanceRequestException

FUTURES_TESTNET_BASE_URL = "https://testnet.binancefuture.com"

logger = logging.getLogger("trading_bot")


class BinanceClientError(Exception):
    """Raised for any client-level failure (network, API, or order error)."""
    pass


class BinanceFuturesTestnetClient:
    def __init__(self, api_key: str, api_secret: str):
        if not api_key or not api_secret:
            raise BinanceClientError("API key and API secret must be provided.")

        try:
            self.client = Client(api_key, api_secret, testnet=True)
            self.client.FUTURES_URL = FUTURES_TESTNET_BASE_URL + "/fapi"
            logger.debug("Binance Futures Testnet client initialized. Base URL: %s", FUTURES_TESTNET_BASE_URL)
        except Exception as exc:
            logger.error("Failed to initialize Binance client: %s", exc)
            raise BinanceClientError(f"Failed to initialize Binance client: {exc}") from exc

    def place_order(self, symbol: str, side: str, order_type: str, quantity: float, price: float = None) -> dict:
        order_params = {
            "symbol": symbol,
            "side": side,
            "type": order_type,
            "quantity": quantity,
        }

        if order_type == "LIMIT":
            order_params["price"] = price
            order_params["timeInForce"] = "GTC"

        logger.info("Sending order request: %s", order_params)

        try:
            response = self.client.futures_create_order(**order_params)
            logger.info("Order response received: %s", response)
            return response

        except (BinanceAPIException, BinanceOrderException) as exc:
            logger.error("Binance API rejected the order: %s", exc)
            raise BinanceClientError(f"Binance API error: {exc}") from exc

        except BinanceRequestException as exc:
            logger.error("Malformed request sent to Binance: %s", exc)
            raise BinanceClientError(f"Request error: {exc}") from exc

        except (ConnectionError, TimeoutError) as exc:
            logger.error("Network failure while contacting Binance: %s", exc)
            raise BinanceClientError(f"Network error: {exc}") from exc

        except Exception as exc:
            logger.error("Unexpected error while placing order: %s", exc)
            raise BinanceClientError(f"Unexpected error: {exc}") from exc