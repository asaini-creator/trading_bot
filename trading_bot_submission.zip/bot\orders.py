"""
orders.py
Order placement logic. Sits between the CLI layer and the client (API) layer.
"""

import logging
from .client import BinanceFuturesTestnetClient, BinanceClientError
from .validators import validate_order_input, ValidationError

logger = logging.getLogger("trading_bot")


def print_order_summary(order: dict) -> None:
    print("\n--- ORDER REQUEST SUMMARY ---")
    print(f"Symbol:   {order['symbol']}")
    print(f"Side:     {order['side']}")
    print(f"Type:     {order['order_type']}")
    print(f"Quantity: {order['quantity']}")
    if order["order_type"] == "LIMIT":
        print(f"Price:    {order['price']}")
    print("-----------------------------\n")


def print_order_response(response: dict) -> None:
    print("--- ORDER RESPONSE DETAILS ---")
    print(f"Order ID:     {response.get('orderId')}")
    print(f"Status:       {response.get('status')}")
    print(f"Executed Qty: {response.get('executedQty')}")
    avg_price = response.get("avgPrice")
    if avg_price is not None:
        print(f"Avg Price:    {avg_price}")
    print("-------------------------------\n")


def execute_order(client: BinanceFuturesTestnetClient, symbol, side, order_type, quantity, price):
    try:
        order = validate_order_input(symbol, side, order_type, quantity, price)
    except ValidationError as exc:
        logger.error("Input validation failed: %s", exc)
        print(f"\n[FAILED] Invalid input: {exc}\n")
        return False

    print_order_summary(order)

    try:
        response = client.place_order(
            symbol=order["symbol"],
            side=order["side"],
            order_type=order["order_type"],
            quantity=order["quantity"],
            price=order["price"],
        )
    except BinanceClientError as exc:
        logger.error("Order placement failed: %s", exc)
        print(f"[FAILED] Order could not be placed: {exc}\n")
        return False

    print_order_response(response)
    print("[SUCCESS] Order placed successfully.\n")
    return True